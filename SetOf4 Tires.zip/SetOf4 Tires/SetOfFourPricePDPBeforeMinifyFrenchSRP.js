
$(document).ready(function(){
CTC.getService('core.communication.mediator').subscribe(CTC.EVENTS.SNP_DATA_RENDERED,function(){
function tnlFourPrice(){
$(".srp-grid__item").each(function(e){
var clearanceBadge = $(this).find("span.auto-product-badges__item.auto-product-badges__item_clearance.clearance__block").length;
var setOfFourPriceTag = $(this).find(".automotive-product-tile-srp__product-data section.automotive-price.automotive-price_clearance.automotive-price_set-of-sku span.automotive-price__current-price .automotive-price__value");

var setOfFourPrice = $(setOfFourPriceTag).text().trim().replace(/\,/g,'').replace(/\$/g,'');
//console.log("set of four"+setOfFourPrice);
//console.log($(setOfFourPriceTag).text());
var setofFourPriceMobileTag = $(this).find(".automotive-product-tile-srp__set-of-4-mobile section.automotive-price.automotive-price_clearance.automotive-price_set-of-sku span.automotive-price__current-price .automotive-price__value");
var setofFourPriceMobile = $(setofFourPriceMobileTag).text().trim().replace(/\,/g,'').replace(/\$/g,'');
//console.log("set of four mobile"+setofFourPriceMobile);
var singlePrice    = $(this).find(".automotive-product-tile-srp__price-with-set-of-4 section.automotive-price.automotive-price_clearance.automotive-price_set-of-sku-part span.automotive-price__current-price  .automotive-price__value").text().trim().replace(/\,/g,'').replace(/\$/g,'');
//console.log("set of four single"+singlePrice);
var newSetOfFourPrice,decimalValue,newValue,digits,newValueFourBeforeComma,newValueFourAfterComma;

 if ( clearanceBadge ) {
   if ( ( setOfFourPrice = singlePrice ) || ( setofFourPriceMobile = singlePrice) ) {
       
        newSetOfFourPrice = 4*setOfFourPrice;
        newValue          = newSetOfFourPrice.toString();
           newValueFourBeforeComma = newValue.slice(0,-2);
        newValueFourAfterComma = newValue.substr(-2);
         //console.log("ready"+newValue);
       
        if (newValue) {
           
      //console.log("inside");
            $(this).find(".automotive-product-tile-srp__product-data section.automotive-price.automotive-price_clearance.automotive-price_set-of-sku span.automotive-price__current-price .automotive-price__value").html('<span class="newPrice">'+ "" +newValueFourBeforeComma+','+newValueFourAfterComma+' $</span>');  
        }
       }
 
 }
});

}

tnlFourPrice();
setTimeout(function(){
tnlFourPrice();
}, 3000);
});
});