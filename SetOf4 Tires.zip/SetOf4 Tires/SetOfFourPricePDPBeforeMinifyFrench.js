var removeIntervalPartentPrice = setInterval(function(){


if ( $(".s7staticimage img").length ) {
      
      clearInterval(removeIntervalPartentPrice);
function tnlFourPrice(){

var buyBoxParent = $(".auto-product-buy-box.section");

var clearanceBadge = $(buyBoxParent).find("span.auto-product-badges__item.auto-product-badges__item_clearance.clearance__block").length;
var setOfFourPriceTag = $(buyBoxParent).find("section.set-of-four-container span.set-of-four-container__price");
var setOfFourPriceTagCoins = $(buyBoxParent).find("section.set-of-four-container span.set-of-four-container__price span.coins");
var setOfFourWasPriceTag = $(buyBoxParent).find("section.set-of-four-container span.set-of-four-container__was--price");
var setOfFourPrice = $(setOfFourPriceTag).text().trim().replace(/\,/g,'').split("$");
var setOfFourWasPrice = $(setOfFourWasPriceTag).text().trim().replace(/\,/g,'').split("$");
var singlePrice    = $(buyBoxParent).find(".price__auto-pdp-content span.price__now--value").text().trim().replace(/\,/g,'').split("$");
var originalPrice    = $(buyBoxParent).find(".price__auto-pdp-content span.price__tag-original-price").text().trim().replace(/\,/g,'').split("$");
var newSetOfFourPrice,decimalValue,newValue,digits,newValueFourBeforeComma,newValueFourAfterComma,newValueFourOriginalBeforeComma,newValueFourOriginalAfterComma;


 if ( clearanceBadge ) {
    
   if ( setOfFourPrice[0] = singlePrice[0]  ) {
        newSetOfFourPrice = 4*setOfFourPrice[0];
        newValueFour          = newSetOfFourPrice.toString();
        newValueFourBeforeComma = newValueFour.slice(0,-2);
        newValueFourAfterComma = newValueFour.substr(-2);


        newSetOfFourPriceOriginal = 4*setOfFourWasPrice[0];
        newValueFourOriginal          = newSetOfFourPriceOriginal.toString();
        newValueFourOriginalBeforeComma = newValueFourOriginal.slice(0,-2);
        newValueFourOriginalAfterComma = newValueFourOriginal.substr(-2);

     

        if ( newValueFour ){
            
            $(buyBoxParent).find("section.set-of-four-container span.set-of-four-container__price").html('<span class="newPrice">'+ "" +newValueFourBeforeComma+',<span class="coins">'+newValueFourAfterComma+'</span> $</span>');
        } 


      if (newValueFourOriginal){
          $(buyBoxParent).find("section.set-of-four-container span.set-of-four-container__was--price").html('<span class="newPrice">'+ "" +newValueFourOriginalBeforeComma+','+newValueFourOriginalAfterComma+' $</span>');

        }
       }
 
 }


}

tnlFourPrice();

    }
    
}, 1000);
  
  
  
  
  function popUp(){
var removeIntervalPartentPricePop = setInterval(function(){
if ( $(".auto-product-confirm-details__price-block").length ) {
      clearInterval(removeIntervalPartentPricePop);
function tnlFourPrice(){

var buyBoxParent = $(".auto-product-confirm-details__price-block");

var clearanceBadge = $(".popup-component__container__body.nano-content span.auto-product-badges__item.auto-product-badges__item_clearance.clearance__block").length;
//console.log(clearanceBadge);
var setOfFourPriceTag = $(buyBoxParent).find(".auto-product-confirm-details__set-of-4 span.automotive-price__current-price span.automotive-price__value");
var setOfFourWasPriceTag = $(buyBoxParent).find(".auto-product-confirm-details__set-of-4 span.automotive-price__old-price  span.automotive-price__value");

var setOfFourPrice = $(setOfFourPriceTag).text().trim().replace(/\,/g,'').split("$");

var setOfFourWasPrice = $(setOfFourWasPriceTag).text().trim().replace(/\,/g,'').replace(/\(/g,'').split("$");

console.log(setOfFourPrice);
console.log(setOfFourWasPrice);

var singlePrice    = $(buyBoxParent).find(".auto-product-confirm-details__info-price span.automotive-price__current-price span.automotive-price__value").text().trim().replace(/\,/g,'').split("$");


var originalPrice    = $(buyBoxParent).find(".auto-product-confirm-details__info-price span.automotive-price__old-price span.automotive-price__value").text().trim().replace(/\,/g,'').split("$");

//console.log(singlePrice);
//console.log(originalPrice);

var newSetOfFourPrice,decimalValue,newValue,digits,newValueFourBeforeComma,newValueFourAfterComma,newValueFourOriginalBeforeComma,newValueFourOriginalAfterComma;


 if ( clearanceBadge ) {
   if ( setOfFourPrice[0] = singlePrice[0]  ) {
       
console.log(setOfFourPrice[0]);
console.log(singlePrice[0]);

        newSetOfFourPrice = 4*setOfFourPrice[0];
        newValueFour          = newSetOfFourPrice.toString();
        newValueFourBeforeComma = newValueFour.slice(0,-2);
        newValueFourAfterComma = newValueFour.substr(-2);

        newSetOfFourPriceOriginal = 4*setOfFourWasPrice[0];
        newValueFourOriginal          = newSetOfFourPriceOriginal.toString();
        newValueFourOriginalBeforeComma = newValueFourOriginal.slice(0,-2);
        newValueFourOriginalAfterComma = newValueFourOriginal.substr(-2);

        if (newValueFour) {
 
            $(buyBoxParent).find(".auto-product-confirm-details__set-of-4 span.automotive-price__current-price span.automotive-price__value").html('<span class="newPrice">'+ "" +newValueFourBeforeComma+',<span class="coins">'+newValueFourAfterComma+'</span> $</span>');   
        }


       if (newValueFourOriginal) {

$(buyBoxParent).find(".auto-product-confirm-details__set-of-4 span.automotive-price__old-price  span.automotive-price__value").html('<span class="newPrice">('+newValueFourOriginalBeforeComma+','+newValueFourOriginalAfterComma+' $</span>');
               }

       }
 
 }


}

tnlFourPrice();

    }
    
}, 1000);

}


$("body").on("click","button.add-to-cart__button",function(){
popUp();
console.log("launched");
});