<script>
  var removeIntervalPartentPrice = setInterval(function(){


if ( $(".s7staticimage img").length ) {
      
      clearInterval(removeIntervalPartentPrice);
function tnlFourPrice(){

var buyBoxParent = $(".auto-product-buy-box.section");

var clearanceBadge = $(buyBoxParent).find("span.auto-product-badges__item.auto-product-badges__item_clearance.clearance__block").length;

var setOfFourPriceTag = $(buyBoxParent).find("section.set-of-four-container span.set-of-four-container__price");

var setOfFourPriceTagCoins = $(buyBoxParent).find("section.set-of-four-container span.set-of-four-container__price span.coins");

var setOfFourWasPriceTag = $(buyBoxParent).find("section.set-of-four-container span.set-of-four-container__was--price");

var setOfFourPrice = $(setOfFourPriceTag).text().replace(/\,/g,'').split("$");

var setOfFourWasPrice = $(setOfFourWasPriceTag).text().replace(/\,/g,'').split("$");

var singlePrice    = $(buyBoxParent).find(".price__auto-pdp-content span.price__now--value").text().replace(/\,/g,'').split("$");


var originalPrice    = $(buyBoxParent).find(".price__auto-pdp-content span.price__tag-original-price").text().replace(/\,/g,'').split("$");



var newSetOfFourPrice,decimalValue,newValue,digits;


 if ( clearanceBadge ) {
   if ( setOfFourPrice[1] = singlePrice[1]  ) {
       
         //console.log("new3"+setOfFourPrice[1]);

        newSetOfFourPrice = 4*setOfFourPrice[1];
        newValueFour          = newSetOfFourPrice.toString();
       //console.log(newSetOfFourPrice );
        //console.log(newValueFour);

        newSetOfFourPriceOriginal = 4*setOfFourWasPrice[1];
        newValueFourOriginal          = newSetOfFourPriceOriginal.toString();

          function splitThreeDigit(){
              digits       = newValueFour.split(".");
              digits[0]    = digits[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
              final_digits = digits.join(".");
              

              digitsOld       = newValueFourOriginal.split(".");
              digitsOld[0]    = digitsOld[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
              final_digitsOld = digitsOld.join(".");
              return final_digitsOld;
              return final_digits;
          }

        if (newValueFour.indexOf('.') !== -1) {
            splitThreeDigit();

            var final_digitsDots =  final_digits.split(".");
//console.log(final_digitsDots[0]);
            $(buyBoxParent).find("section.set-of-four-container span.set-of-four-container__price").html('<span class="newPrice">$'+ "" +final_digitsDots[0]+'.<span class="coins">'+final_digitsDots[1]+'</span></span>');   
        }


       if (newValueFourOriginal.indexOf('.') !== -1) {
splitThreeDigit();
$(buyBoxParent).find("section.set-of-four-container span.set-of-four-container__was--price").html('<span class="newPrice">$'+ "" +final_digitsOld+'</span>');
               }


        if ( newValueFour.indexOf('.') == -1 ){
            splitThreeDigit();
            $(buyBoxParent).find("section.set-of-four-container span.set-of-four-container__price").html('<span class="newPrice">$'+ "" +final_digits+'<span class="coins">.00</span></span>');
        } 


      if (newValueFourOriginal.indexOf('.') == -1){
          $(buyBoxParent).find("section.set-of-four-container span.set-of-four-container__was--price").html('<span class="newPrice">$'+ "" +final_digitsOld+'<span class="coins">.00</span></span>');

        }
       }
 
 }


}

tnlFourPrice();

    }
    
}, 1000);
  
  
  
  
  function popUp(){
var removeIntervalPartentPricePop = setInterval(function(){
if ( $(".auto-product-confirm-details__price-block").length ) {
      clearInterval(removeIntervalPartentPricePop);
function tnlFourPrice(){

var buyBoxParent = $(".auto-product-confirm-details__price-block");

var clearanceBadge = $(".popup-component__container__body.nano-content span.auto-product-badges__item.auto-product-badges__item_clearance.clearance__block").length;
//console.log(clearanceBadge);
var setOfFourPriceTag = $(buyBoxParent).find(".auto-product-confirm-details__set-of-4 span.automotive-price__current-price span.automotive-price__value");
var setOfFourWasPriceTag = $(buyBoxParent).find(".auto-product-confirm-details__set-of-4 span.automotive-price__old-price  span.automotive-price__value");

var setOfFourPrice = $(setOfFourPriceTag).text().replace(/\,/g,'').split("$");

var setOfFourWasPrice = $(setOfFourWasPriceTag).text().replace(/\,/g,'').split("$");

//console.log(setOfFourPrice);
//console.log(setOfFourWasPrice);

var singlePrice    = $(buyBoxParent).find(".auto-product-confirm-details__info-price span.automotive-price__current-price span.automotive-price__value").text().replace(/\,/g,'').split("$");


var originalPrice    = $(buyBoxParent).find(".auto-product-confirm-details__info-price span.automotive-price__old-price span.automotive-price__value").text().replace(/\,/g,'').split("$");

//console.log(singlePrice);
//console.log(originalPrice);

var newSetOfFourPrice,decimalValue,newValue,digits;


 if ( clearanceBadge ) {
   if ( setOfFourPrice[1] = singlePrice[1]  ) {
       
//console.log("insie");
       

        newSetOfFourPrice = 4*setOfFourPrice[1];
        newValueFour          = newSetOfFourPrice.toString();
   

        newSetOfFourPriceOriginal = 4*setOfFourWasPrice[1];
        newValueFourOriginal          = newSetOfFourPriceOriginal.toString();

          function splitThreeDigit(){
              digits       = newValueFour.split(".");
              digits[0]    = digits[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
              final_digits = digits.join(".");
              

              digitsOld       = newValueFourOriginal.split(".");
              digitsOld[0]    = digitsOld[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
              final_digitsOld = digitsOld.join(".");
              return final_digitsOld;
              return final_digits;
          }

        if (newValueFour.indexOf('.') !== -1) {
            splitThreeDigit();

            var final_digitsDots =  final_digits.split(".");
//console.log(final_digitsDots[0]);
            $(buyBoxParent).find(".auto-product-confirm-details__set-of-4 span.automotive-price__current-price span.automotive-price__value").html('<span class="newPrice">$'+ "" +final_digitsDots[0]+'.<span class="coins">'+final_digitsDots[1]+'</span></span>');   
        }


       if (newValueFourOriginal.indexOf('.') !== -1) {
splitThreeDigit();
$(buyBoxParent).find(".auto-product-confirm-details__set-of-4 span.automotive-price__old-price  span.automotive-price__value").html('<span class="newPrice">($'+ "" +final_digitsOld+'</span>');
               }


        if ( newValueFour.indexOf('.') == -1 ){
            splitThreeDigit();
            $(buyBoxParent).find(".auto-product-confirm-details__set-of-4 span.automotive-price__current-price span.automotive-price__value").html('<span class="newPrice">$'+ "" +final_digits+'<span class="coins">.00</span></span>');
        } 


      if (newValueFourOriginal.indexOf('.') == -1){
          $(buyBoxParent).find(".auto-product-confirm-details__set-of-4 span.automotive-price__old-price  span.automotive-price__value").html('<span class="newPrice">($'+ "" +final_digitsOld+'<span class="coins">.00</span></span>');

        }
       }
 
 }


}

tnlFourPrice();

    }
    
}, 1000);

}


$("body").on("click","button.add-to-cart__button",function(){
popUp();

});
</script>