<script>


var removeIntervalPartent = setInterval(function(){


if ( $(".s7staticimage img").length ) {

clearInterval(removeIntervalPartent);



var priceCurrentNotification = window.CTC.GTM.mediator["_history"]["pdp-current-price-notification"];
var priceCurrentNotificationLength = $(priceCurrentNotification).length;
var totalEnvironFee;
var finalTotalEnvironFee;
var finalTotalEnvironFeeLength;


function checkEnfironFee(){
  for(environFee in priceCurrentNotification )
    {
    totalEnvironFee = priceCurrentNotification[environFee];                
        finalTotalEnvironFee = totalEnvironFee["TotalEnviroFee"]; 
        finalTotalEnvironFeeLength =   $(finalTotalEnvironFee).length;     
         }
    return finalTotalEnvironFeeLength;
}

function addIcon(){

var pdpRecycleFeeMessage = $(".set-of-four-container__eco-fee");
var messageLength        = $(pdpRecycleFeeMessage).length;
var rebateicone          = $('<sup class="new-rebate-icon">△</sup>');
var newRebateIcon        = $(pdpRecycleFeeMessage).append(rebateicone);



if ( ( messageLength > 0) && ($(window).width() > 800) ) {
  $(newRebateIcon);
  $(pdpRecycleFeeMessage).wrap('<a class="rebateClass" href="#tire-rebate"></a>');

}

if ( ( messageLength > 0) && ($(window).width() < 800) ) {
  $(newRebateIcon);
  $(pdpRecycleFeeMessage).wrap('<a class="rebateClass" href="#tire-rebates"></a>');
}

/* Click Scroll Function */


$(document).on("click","a.rebateClass",function(){
            $("html, body").animate({ scrollTop: $($(this).attr("href")).offset().top}, 1000);
});

$(document).on("click touchstart","a.rebateClass",function(){
            $("html, body").animate({ scrollTop: $($(this).attr("href")).offset().top}, 1000);
});

/* End of Click Scroll Function */



}

var removeInterval = setInterval(function(){
   
    if( priceCurrentNotificationLength ){
        clearInterval(removeInterval);
        checkEnfironFee();
         if ( finalTotalEnvironFeeLength ){


        addIcon();
           }

    }
    
}, 1000);



}





/* This is for popup */


$("body").on("click","button.add-to-cart__button",function(){
afterAddtoCartClick();
});

$("body").on("click touchstart","button.add-to-cart__button",function(){
afterAddtoCartClick();
});
function afterAddtoCartClick(){

var removeIntervalPopUp = setInterval(function() {

var lengthOfPopUp = $(".popup-component__container__body.nano.has-scrollbar").children().length;

if ( lengthOfPopUp ) {

   clearInterval(removeIntervalPopUp );
   addIcon();
}

function addIcon(){
var pdpRecycleFeeMessageNew = $(".automotive-price__fees");
var pdpRecycleFeeMessageLengthNew = $(pdpRecycleFeeMessageNew).length;
var rebateiconeNew          = $('<sup class="new-rebate-icon">△</sup>');
var footerMessageDivNew     = $('.popup-component__container__body.nano.has-scrollbar');
var footerMessageNew        = $('<font class="recyleFeePopUp"><sup>△</sup>The tire producer / manufacturer is responsible for the recycling fee charged on new tires. All fees collected go towards the collection, transportation and processing costs of recycling used tires.</font>');
var lengthOfNewIcon         = $(".automotive-price__fees .new-rebate-icon").length;

if ( pdpRecycleFeeMessageLengthNew) {

if ( lengthOfNewIcon < 1 ){
  
  $(pdpRecycleFeeMessageNew).append(rebateiconeNew);
} 
if ( $(".recyleFeePopUp").length < 1 ) {
  $(footerMessageDivNew).append(footerMessageNew)
}
}

}


}, 1000);

}
    
}, 1000);
/* End of the popup */

</script>
<style>

.set-of-four-container__eco-fee span.info-bubble.bottom {
    display: none;
}
.recyleFeePopUp {
padding: 10px 20px 10px;
    display: block;
    font-size: 11px;
}
span.info-bubble.bottom {

  display:none;
}

</style>