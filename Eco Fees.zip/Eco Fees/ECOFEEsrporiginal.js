<script>
  
  
  CTC.getService('core.communication.mediator').subscribe(CTC.EVENTS.SNP_DATA_RENDERED,function(){
//console.log("code is working");
var srpTiles = $(".srp-grid__item");

function rebateClass(){

var autoFee = $(".automotive-price__fees");
var featuredItem = $(".featured-product-item__wrp");
var _this;
function insideCall(_this){

if ( $(_this).find(autoFee).find(".new-rebate-icon").length < 1 ) {
$(_this).find(autoFee).append('<sup class="new-rebate-icon">△</sup>');
$(_this).find(autoFee).wrap('<a class="rebateClass" href="#tires-rebate"></a>');

}
}

$(featuredItem).each(function(){
_this = $(this);
insideCall(_this);
});

$(srpTiles).each(function(){
_this = $(this);
insideCall(_this);
});

}

rebateClass();


setTimeout(function(){
rebateClass();
}, 2000);


       
$(srpTiles).each(function(){
    var _thisThis = $(this).find("a.automotive-product-tile-srp.automotive-product-tile-srp_wheel-tire");
	    $(this).find("a.rebateClass").on("click",function(){
	        $(_thisThis).attr("href","#tires-rebate");
	    });
        
        var original = $(_thisThis).attr("href");

	    $(this).find("a.rebateClass").mouseover(function(){
	        $(_thisThis).attr("href","#tires-rebate");
	    });
	    $(this).find("a.rebateClass").mouseout(function(){
	        $(_thisThis).attr("href",original);
	    });
});

  $(document).on("click","a.rebateClass",function(){
            $("html, body").animate({ scrollTop: $($(this).attr("href")).offset().top}, 1000);
   });


});
</script>