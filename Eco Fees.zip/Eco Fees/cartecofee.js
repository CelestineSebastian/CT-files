<script>

var removeIntervalPartent = setInterval(function(){

var dataCodeValue = $("li.checkout-order-summary__in-your-cart__product").attr("data-skucode");

if ( typeof dataCodeValue !== typeof undefined && dataCodeValue !== false ) {

clearInterval(removeIntervalPartent);

var priceCurrentNotification = window.CTC.GTM.mediator["_history"]["get-shopping-cart"]; 
var passId;
var storeData;
var shppingCartFeesOntarioDesktop      = $('<a class="rebateClass automotive-price__fees" href="#tire-rebate">Frais inclus:  18,00 $ de recyclage des pneus<sup class="new-rebate-icon">△</sup></a>');
var shppingCartFeesQCDesktop      = $('<a class="rebateClass automotive-price__fees" href="#tire-rebate">Frais inclus: 12,00 $ Envir<sup class="new-rebate-icon">△</sup></a>');
var shppingCartFeesOtherDesktop      = $('<a class="rebateClass automotive-price__fees" href="#tire-rebate">Frais inclus: 20,00 $ Envir<sup class="new-rebate-icon">△</sup></a>');

var shppingCartFeesOntarioMobile      = $('<a class="rebateClass automotive-price__fees" href="#tire-rebates">Frais inclus:  18,00 $ de recyclage des pneus<sup class="new-rebate-icon">△</sup></a>');
var shppingCartFeesQCMobile     = $('<a class="rebateClass automotive-price__fees" href="#tire-rebates">Frais inclus: 12,00 $ Envir<sup class="new-rebate-icon">△</sup></a>');
var shppingCartFeesOtherMobile      = $('<a class="rebateClass automotive-price__fees" href="#tire-rebates">Frais inclus: 20,00 $ Envir<sup class="new-rebate-icon">△</sup></a>');





for(environFee in priceCurrentNotification )
    {
       var totalEnvironFee = priceCurrentNotification[environFee]["products"]; 
       var totalEnvironFeeNew = priceCurrentNotification[environFee]["storeData"];    

        for(environFee1 in totalEnvironFee ) {

           var totalEnvironFeeFinal = totalEnvironFee[environFee1];
        
            passId =  totalEnvironFeeFinal["id"];
             for ( store1 in totalEnvironFeeNew ) {
                    storeData = totalEnvironFeeNew["address"]["region"]["code"];
                }
            a(passId,storeData);
          
           
          


        }
    }





function a(passId,storeData){
$("li.checkout-order-summary__in-your-cart__product").each(function(){

var dataCode = $(this).attr("data-skucode");

var quantity = $(".checkout-order-summary__in-your-cart__product__name-and-quantity");
var $quantityAppend = $(this).find(quantity);
if ( passId == dataCode ) {

        if ( ( $(window).width() > 800 ) && ( $(".rebateClas").length < 1 ) ) {

              if ( storeData == "ON" ) {
                $quantityAppend.append(shppingCartFeesOntarioDesktop);
              }
              if ( storeData == "QC" ) {
                $quantityAppend.append(shppingCartFeesQCDesktop);
              }
              if ( (storeData !== "ON") && (storeData !== "QC") ) {
                $quantityAppend.append(shppingCartFeesOtherDesktop);
              }
            

        }

        
        if ( ( $(window).width() < 800 ) && ( $(".rebateClas").length < 1 ) ) {
        

          if ( storeData == "ON" ) {
                $quantityAppend.append(shppingCartFeesOntarioMobile);
              }
              if ( storeData == "QC" ) {
                $quantityAppend.append(shppingCartFeesQCMobile);
              }
              if ( (storeData !== "ON") && (storeData !== "QC") ) {
                $quantityAppend.append(shppingCartFeesOtherMobile);
              }

        }
}


});

$(document).on("click","a.rebateClass",function(){
            $("html, body").animate({ scrollTop: $($(this).attr("href")).offset().top}, 1000);
});

}



}

}, 1000);

</script>


<style>

.rebateClass {

	color:#333;
}
</style>