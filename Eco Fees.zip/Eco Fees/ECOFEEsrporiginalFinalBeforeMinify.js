<script>
  
  
 CTC.getService('core.communication.mediator').subscribe(CTC.EVENTS.SNP_DATA_RENDERED,function(){
//console.log("code is working");
var srpTiles = $(".srp-grid__item");


function insideCall(_this){


var afterinsert = $(_this).find('a.automotive-product-tile-srp.automotive-product-tile-srp_wheel-tire');
var badgePrepend = $(_this).find('.automotive-product-tile-srp__info');

if ( $(_this).find(".tnl_price_info").length < 1 ) {
	$(_this).find('.automotive-price__fees').addClass("tnl_price_info").insertAfter(afterinsert);

    /* Move clearance Badge */
    $(_this).find("span.auto-product-badges__item.auto-product-badges__item_clearance.clearance__block").parent().parent().prependTo(badgePrepend);

    /* End of the clearance Badge */

}

if (  $(_this).find(".new-rebate-icon").length < 1 ) {

$(_this).find(".automotive-price__fees").append('<sup class="new-rebate-icon">△</sup>');

}

if ( $(window).width() > 800 ){
$(document).on("click",".automotive-price__fees",function(event) {
    event.stopImmediatePropagation();
    $('html,body').animate({
        scrollTop: $("#tire-rebate").offset().top},
        'slow');
});

}

if ( $(window).width() < 800 ){
$(document).on("click touchstart",".automotive-price__fees",function(event) {
    event.stopImmediatePropagation();
    $('html,body').animate({
        scrollTop: $("#tire-rebates").offset().top},
        'slow');
});

}

}

function newRebateClass(){
$(".featured-product-item__wrp").each(function(){

var featuredIcon = $(this).find('.automotive-price__fees').find("span.price__fees-fee");
var rebateIconNew = $(this).find(".new-rebate-icon");
if ( $(rebateIconNew).length < 1 ){

    $(featuredIcon).append('<sup class="new-rebate-icon">△</sup>');
}

});
}

function rebateClass(){
$(srpTiles).each(function(){
_this = $(this);
insideCall(_this);
});
}

newRebateClass();
rebateClass();
setTimeout(function(){
rebateClass();
newRebateClass();
}, 3000);


});
  
</script>

<style>
.automotive-price__fees.tnl_price_info {
    line-height: 0.8;
}
.automotive-price_set-of-sku-featured span.automotive-price__fees {
    display: flex;
}
.automotive-price__fees.tnl_price_info {
    position: absolute;
    right: 10px;
    bottom: 81px;
}

.srp-grid__item.srp-grid__item_sku {
    position: relative;
    
}

.automotive-product-tile-srp__button {
    margin-top: 40px;
}

span.info-bubble.bottom,.automotive-price__fees.tnl_price_info:last-child,.automotive-price__fees.tnl_price_info:nth-last-child(2) {
    display: none;
}

@media only screen and (max-width:600px){
    .automotive-price__fees.tnl_price_info {
    font-size: 12px;
    bottom: 8px;
} 
.srp-grid__item.srp-grid__item_sku {
    padding-bottom: 20px;
}
}
</style>