<script>

var removeIntervalPartent = setInterval(function(){

var dataCodeValue = $("li.checkout-order-summary__in-your-cart__product").attr("data-skucode");

if ( typeof dataCodeValue !== typeof undefined && dataCodeValue !== false ) {

clearInterval(removeIntervalPartent);

var priceCurrentNotification = window.CTC.GTM.mediator["_history"]["header-cart-change"]; 
var passId;
for(environFee in priceCurrentNotification )
    {
       var totalEnvironFee = priceCurrentNotification[environFee];      
        for(environFee1 in totalEnvironFee ) {

           var totalEnvironFeeFinal = totalEnvironFee[environFee1];
          
           var ecoFees = totalEnvironFeeFinal["ecoFees"];
           if ( ( typeof ecoFees == 'number') && ecoFees > 0 ) {
            
            passId =  totalEnvironFeeFinal["id"];
            a(passId,ecoFees);
           }
           
          


        }
    }

function a(passId,ecoFees){
$("li.checkout-order-summary__in-your-cart__product").each(function(){

var dataCode = $(this).attr("data-skucode");

var quantity = $(".checkout-order-summary__in-your-cart__product__name-and-quantity");

if ( passId == dataCode ) {

        if ( ( $(window).width() > 800 ) && ( $(".rebateClas").length < 1 ) ) {
        $(this).find(quantity).append('<a class="rebateClass automotive-price__fees" href="#tire-rebate">+'+" "+'$'+ecoFees+" "+'Tires Recycle Fee<sup class="new-rebate-icon">△</sup></a>');

        }

        
        if ( ( $(window).width() < 800 ) && ( $(".rebateClas").length < 1 ) ) {
        $(this).find(quantity).append('<a class="rebateClass automotive-price__fees" href="#tire-rebates">+'+" "+'$'+ecoFees+" "+'Tires Recycle Fee<sup class="new-rebate-icon">△</sup></a>');

        }
}


});

$(document).on("click","a.rebateClass",function(){
            $("html, body").animate({ scrollTop: $($(this).attr("href")).offset().top}, 1000);
});

}



}

}, 1000);

</script>


<style>

.rebateClass {

	color:#333;
}
</style>