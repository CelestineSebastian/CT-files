<script>
$(document).ready(function(){
CTC.getService('core.communication.mediator').subscribe(CTC.EVENTS.SHOPPING_CART_ITEM_RENDERED,function(){

var cartValue = $(".shopping-cart-item").children().length;

if ( cartValue > 0) {
	callCart();
	
}

});

function callCart(){
	//console.log("endted");
$(".shopping-cart__consignment-item").each(function(){

var lengthOfIcon 		 = $(this).find("p.shopping_cart_fees .new-rebate-icon").length;
var carRecycleFeeMessage = $(this).find("p.shopping_cart_fees");
var rebateicone 		 = $('<sup class="new-rebate-icon">△</sup>');



if ( ( lengthOfIcon < 1) && ( $(window).width() > 800 ) ) {
                $(carRecycleFeeMessage).append(rebateicone);
                $(carRecycleFeeMessage).wrap('<a class="rebateClass" href="#tire-rebate"></a>');
            }

if ( ( lengthOfIcon < 1) && ( $(window).width() < 800 ) ) {

            $(carRecycleFeeMessage).append(rebateicone);
                $(carRecycleFeeMessage).wrap('<a class="rebateClass" href="#tire-rebates"></a>');
}
             $(document).on("click", "a.rebateClass", function(event) {
                //console.log("clickclcick");
                event.stopImmediatePropagation();
                $("html, body").animate({
                    scrollTop: $($(this).attr("href")).offset().top
                }, 1000);
            });

});

}
});

</script>


<style>

span.info-bubble.top {
	display:none;
}
</style>