<script>
  


CTC.getService('core.communication.mediator').subscribe(CTC.EVENTS.SNP_DATA_RENDERED,function(){
//console.log("code is working");
var srpTiles = $(".srp-grid__item");



function rebateClass(){

var autoFee = $(".automotive-price__fees");
var featuredItem = $(".featured-product-item__wrp");
var _this;

function insideCall(_this){


if (  $(_this).find(autoFee).find(".new-rebate-icon").length < 1 ) {

$(_this).find(autoFee).find("span.price__fees-fee").append('<sup class="new-rebate-icon">△</sup>');

if ( $(window).width() > 800 ){
$(_this).find(autoFee).find("span.price__fees-fee").wrapInner('<a class="rebateClass tooltip__toggle price__fees-charge" href="#tire-rebate"></a>');
}
if ( $(window).width() < 800 ){
$(_this).find(autoFee).find("span.price__fees-fee").wrapInner('<a class="rebateClass tooltip__toggle price__fees-charge" href="#tire-rebates"></a>');
}
}

}


$(featuredItem).each(function(){
_this = $(this);
insideCall(_this);
});

$(srpTiles).each(function(){
_this = $(this);
insideCall(_this);
});

}

rebateClass();
setTimeout(function(){
rebateClass();
}, 2000);

  $(document).on("click", "a.rebateClass", function(event) {
                //console.log("clickclcick");
                event.stopImmediatePropagation();
                $("html, body").animate({
                    scrollTop: $($(this).attr("href")).offset().top
                }, 1000);
            });

});

</script>