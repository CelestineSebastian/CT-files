<script>
  
 CTC.getService('core.communication.mediator').subscribe(CTC.EVENTS.SNP_DATA_RENDERED,function(){
//console.log("code is working");
var srpTiles = $(".temporary-grid-item");


function insideCall(_this){

var afterinsert = $(_this).find('a.product-tile-srp__main-link');
$(_this).find('.product-tile__price-info').addClass("tnl_price_info").insertAfter(afterinsert);

if (  $(_this).find(".new-rebate-icon").length < 1 ) {

$(_this).find("span.price__fees-fee").append('<sup class="new-rebate-icon">△</sup>');

}




if ( $(window).width() > 800 ){
$(document).on("click",".product-tile__price-info",function(event) {
event.stopImmediatePropagation();

    $('html,body').animate({
        scrollTop: $("#tire-rebate").offset().top},
        'slow');
});

}

if ( $(window).width() < 800 ){
$(document).on("click touchstart",".product-tile__price-info",function(event) {
event.stopImmediatePropagation();
    $('html,body').animate({
        scrollTop: $("#tire-rebates").offset().top},
        'slow');
});

}

}

function rebateClass(){
$(srpTiles).each(function(){
_this = $(this);
insideCall(_this);
});
}

rebateClass();
setTimeout(function(){
rebateClass();
}, 2000);


});



</script>

<style>
  
  .product-tile__price-info.tnl_price_info {
    text-transform: inherit !important;
}
  .product-tile__price-info.tnl_price_info {
    color: #333;
    position: absolute;
    bottom: 88px;
    left: 26px;
}
  
  
span.info-bubble.bottom {
	
	display:none;
	
}

.grid--list-view .product-tile__price-info.tnl_price_info {
    left: 234px;
    bottom: 152px;
}

.grid--list-view .product-tile-srp__details .product-tile-srp__title-and-rate-wrapper {
    padding-top: 31px;
}


@media only screen and (max-width:600px) {
	.product-tile__price-info.tnl_price_info {


	bottom: 63px;
    left: 6px;
    	}
}

@media only screen and (max-width:320px) {
	.product-tile__price-info.tnl_price_info {
	bottom: 81px;
    	}
}
  
</style>