<script>

var initSignUPpopUp = function($) {

if ($(window).width() > 800)
  {
 $('<div class="modal fade" id="slide-bottom-popup" data-keyboard="false" data-backdrop="false"><div class="modal-body"><button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div class="tnl-parent-flex"><span class="tnl-image-flex"><img src="https://canadiantire.scene7.com/is/image/CanadianTire/mail-blue48px?wid=48&hei=48&fmt=png-alpha"></span><p>Get a bonus of <b>10% off</b> your next purchase when you join our email community. Be first to receive new releases,exclusive deals, plus more.</p><a href="https://www.sportchek.ca/sign-up.html" id="tnl-signUp" class="btn-primary btn-plain btn popup-button">SIGN UP</a></div></div></div>').appendTo('body');
  }

if ($(window).width() < 800)
  {
  $('<div class="modal fade" id="slide-bottom-popup" data-keyboard="false" data-backdrop="false"><div class="modal-body"><button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div class="tnl-parent-flex"><span class="tnl-image-flex"><img src="https://canadiantire.scene7.com/is/image/CanadianTire/mail-blue48px?wid=48&hei=48&fmt=png-alpha"><p>Join our email community!</p></span><p>Get a bonus offer of<b> 10% off </b>your next Purchase. Be first to receive new releases, exclusive deals, plus more.</p><a href="https://www.sportchek.ca/sign-up.html" id="tnl-signUp" class="btn-primary btn-plain btn popup-button">SIGN UP</a></div></div></div>').appendTo('body');
  }
 $(document).ready(function() {
/* Cookie */         
function setCookie(cookieName, cookieValue) {
 var d = new Date();
 d.setTime(d.getTime() + (120*60*24*60*1000));
 var expires = "expires="+ d.toUTCString();
 document.cookie = cookieName + "=" + cookieValue + ";" + expires;
}

function getCookie(cookieName) {
 var name = cookieName + "=";
 var ca = document.cookie.split(';');
 for(var i = 0; i < ca.length; i++) {
  var c = ca[i];
  while (c.charAt(0)==' ') {
   c = c.substring(1);
  }
  if (c.indexOf(name) == 0) {
   return c.substring(name.length,c.length);
  }
 }
 return "";
}

(function(){
var checkValue = (getCookie('signUpPopUpSportchek') != 'Shown');
switch(checkValue) {
    case true:
        setTimeout(function() {
            //$('#slide-bottom-popup').modal('show');
            $('#slide-bottom-popup').animate({bottom:'0px'},1150);
            
        }, 1500);
        break;
}
})();
/* End of Cookie */

   
      var $closeButton  = $("button.close");
      var $removeIn     = $('#slide-bottom-popup');
      $(document).on("click",".tnl-parent-flex .btn-primary",function(){
        
          setCookie("signUpPopUpSportchek", "Shown");
          $removeIn.animate({bottom:'-300px'},1150);
          $closeButton.click();
            
      });
      $(document).on("click","button.close",function(){
          setCookie("signUpPopUpSportchek", "Shown");
          $removeIn.animate({bottom:'-300px'},1150);
    
      });

   $("body").on("click",function (e)
    {
    var container = $("div#slide-bottom-popup");  // Add an elemet to target

    if (!container.is(e.target) && container.has(e.target).length === 0)
    {
        
          setCookie("signUpPopUpSportchek", "Shown");
          $removeIn.animate({bottom:'-300px'},1150);
    }
}); 


});

};



// Wait for jquery to load first
var waitForjQueryPlaceholderSignUPpopUp = setInterval(function() {
  if (window.jQuery) {
    clearInterval(waitForjQueryPlaceholderSignUPpopUp);
    initSignUPpopUp(jQuery);
  }
}, 50);

</script>

<style>

.tnl-parent-flex b {
    font-family: GalaxieCondensedBold,Arial,sans-serif;
}
.tnl-parent-flex > p,span.tnl-image-flex p {
    font-family: GalaxieCondensedBook,Arial,sans-serif;
}

#tnl-signUp.btn-primary {
    font-family: GalaxieCondensedBold,Arial,sans-serif;
    letter-spacing: 0.5px;
}
button.close {
   
    font-size: 28px;
    font-weight: 500 !important;
    font-family: GalaxieCondensedBook,Arial,sans-serif;
    }
.fade {
    
    box-shadow: 0px -1px 8px #00000034;
}

div#slide-bottom-popup {
bottom: -300px;
width: 100%;
opacity: 1;
z-index: 99999;
}

.modal-body {
    width: 100%;
    background-color: #fff;
    border-radius: 6px 6px 0 0;
    opacity: 1;
    box-shadow: 0px -1px 8px #00000034;
    padding: 25px 15px;
    padding-bottom:16px;
}
.close {
    margin-top: -20px;
    text-shadow: 0 1px 0 #ffffff;
}
.popup-button {
    font-weight: bold;
}
.tnl-parent-flex {
    display:flex;align-items:center;justify-content: center;
     max-width: 1300px;
    margin: 0 auto;}
.tnl-parent-flex p {
    font-size: 20px;
    margin-bottom: 0;
}
.tnl-image-flex {

display:flex;align-items:center;justify-content: center;
}
#tnl-signUp.btn-primary {
    background: #333333;
    width: 143px;
    height: 44px;
    padding: 0;
    background-image: none;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    background-position: unset;
    margin-left: 40px;
    border-radius: 8px;
}
button.close {
    opacity: 1;
    
}
#tnl-signUp.btn-primary:hover, #tnl-signUp.btn-primary:focus {
    background: #333;
    opacity: 0.9;
}
.close:hover, .close:focus {

    opacity:0.6;
}
span.tnl-image-flex img {
    margin-right: 10px;
}
.tnl-image-flex {
    margin-right: 5px;
}

button.close {
    padding: 0;
    cursor: pointer;
    background: transparent;
    border: 0;
    -webkit-appearance: none;
   
    line-height: 1;
    color: #000;
    filter: alpha(opacity=20);
    position: absolute;
    right: 30px;
}

span.sr-only {
    position: absolute;
    width: 1px;
    height: 1px;
    margin: -1px;
    padding: 0;
    overflow: hidden;
    clip: rect(0,0,0,0);
    border: 0;
}
.tnl-parent-flex p {
    margin-top: 0;
}


.modal {
   
    overflow: hidden;
    position: fixed;
   
    right: 0;
    bottom: 0;
    left: 0;
    z-index: 8050;
    -webkit-overflow-scrolling: touch;
    outline: 0;
}

/*
.fade.in {
    opacity: 1;
    display: block;
}
*/
a#tnl-signUp {
    color: #fff;
}

.tnl-image-flex {
    margin-right: 10px;
}
span.tnl-image-flex:after {

    display:none;
}

.tnl-parent-flex p {
   max-width: 850px;
}

@media only screen and (max-width:1440px){
    /*.tnl-parent-flex {
        max-width: 1150px;
    }
    */
    .tnl-parent-flex p {
   max-width: 700px;
}
}


@media only screen and (max-width:1080px) and (min-width:1016px) {

button.close {
    right:10px;
    }
}
@media only screen and (max-width:1015px) and (min-width:759px) {

/* .modal-body {
    padding-right: 30px;
    padding-left: 5px;
} */

.tnl-parent-flex p {
    font-size: 16px;
}
#tnl-signUp.btn-primary {
    width: 90px;
    height: 35px;
    margin-left: 13px;
    font-size: 13px;
}

span.tnl-image-flex img {
    margin-right: 0;
}


#tnl-signUp.btn-primary {
      font-size:11px
    }
    button.close {
    right:15px;
    }
}

@media only screen and (max-width:880px){

.close {
        margin-top: -12px;
}
span.tnl-image-flex p {
    font-size: 20px;
}
button.close {
    right:15px;
    font-weight: 500;
    }

    #tnl-signUp.btn-primary {
      font-size:13px !important;
    }
span.tnl-image-flex img {
    margin-right:8px !important;
    height:36px;
}
.tnl-image-flex {
    margin-right: 10px;
}

.modal-body {
    padding:25px;
    padding-bottom: 16px;
    padding-top:20px;
}

.tnl-parent-flex {
    flex-direction: column;
    align-items: self-start;
}

#tnl-signUp.btn-primary {
    margin-left: 0; 
    width: 100%;
    margin-top: 6px;
}
.tnl-parent-flex > p {
    margin-left: 0px !important;
    margin: 10px;
     font-size: 16px;
     margin-right:0;
}
}

</style>