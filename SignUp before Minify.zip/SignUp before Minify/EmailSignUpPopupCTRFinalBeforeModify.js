<script>
  
 $('<div class="modal fade" id="slide-bottom-popup" data-keyboard="false" data-backdrop="false"><div class="modal-body"><button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><div class="tnl-parent-flex"><span class="tnl-image-flex"><img src="https://canadiantire.scene7.com/is/image/CanadianTire/mail-green48px?wid=48&hei=48&fmt=png-alpha"><p>Join our email community!</p></span><p>Get exclusive deals and awesome sales right to your inbox.</p><button class="btn-primary btn-plain btn popup-button">SIGN UP</button></div></div></div>').appendTo('body');
  
 $(document).ready(function() {
/* Cookie */         
function setCookie(cookieName, cookieValue) {
 var d = new Date();
 d.setTime(d.getTime() + (120*60*24*60*1000));
 var expires = "expires="+ d.toUTCString();
 document.cookie = cookieName + "=" + cookieValue + ";" + expires;
}

function getCookie(cookieName) {
 var name = cookieName + "=";
 var ca = document.cookie.split(';');
 for(var i = 0; i < ca.length; i++) {
  var c = ca[i];
  while (c.charAt(0)==' ') {
   c = c.substring(1);
  }
  if (c.indexOf(name) == 0) {
   return c.substring(name.length,c.length);
  }
 }
 return "";
}

(function(){
var checkValue = (getCookie('signUpPopUp') != 'Shown');
switch(checkValue) {
    case true:
        setTimeout(function() {
            $('#slide-bottom-popup').modal('show');
        }, 3000);
        break;
}
})();
/* End of Cookie */

   
      var $closeButton  = $("button.close");
      $(document).on("click",".tnl-parent-flex .btn-primary",function(){
          var $signUpButton = $("a.category-tiles__link.email-signup__link")[0];
          setCookie("signUpPopUp", "Shown");
          $closeButton.click();
            $signUpButton.click();
      });
      $(document).on("click","button.close",function(){
          setCookie("signUpPopUp", "Shown");
      });

      $(document).click(function (e)
      {
    var container = $("div#slide-bottom-popup");  // Add an elemet to target

    if (!container.is(e.target) && container.has(e.target).length === 0)
    {
         setCookie("signUpPopUp", "Shown");
         var bottomValue = $("div#slide-bottom-popup").css("display");
         if ( bottomValue == "block" ){
          $closeButton.click();
         }
          
    }
});

});

</script>


<style>
  .close {
    font-weight: 500 !important;
}
  .modal.fade.in .modal-body {
    bottom: 0; 
    opacity: 1;
}
.modal {
    top: calc(100% - 105px) !important;
}
.modal-body {
    position: absolute;
    bottom: -250px;
    padding: 30px 15px 15px;
    width: 100%;
    background-color: #fff;
    border-radius: 6px 6px 0 0;
    opacity: 0;
    -webkit-transition: opacity 1.3s ease-out, bottom 1.3s ease-out;
    -moz-transition: opacity 1.3s ease-out, bottom 1.3s ease-out;
    -o-transition: opacity 1.3s ease-out, bottom 1.3s ease-out;
    transition: opacity 1.3s ease-out, bottom 1.3s ease-out;
     box-shadow: 0px -1px 8px #00000034;
    padding: 25px 15px;
}
.close {
   margin-top: -14px;
    text-shadow: 0 1px 0 #ffffff;
    position: relative;
    right: 14px;
}
.popup-button {
    font-weight: bold;
}
.tnl-parent-flex {
    display:flex;align-items:center;justify-content: center;
     max-width: 1150px;
    margin: 0 auto;}
.tnl-parent-flex p {
    font-size: 20px;
    margin-bottom: 0;
}
.tnl-image-flex {

display:flex;align-items:center;justify-content: center;
}
.btn-primary {
    background: #333333;
    width: 143px;
    height: 44px;
    padding: 0;
    background-image: none;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    background-position: unset;
    margin-left: 40px;
    border-radius: 8px;
}
button.close {
    opacity: 1;
    font-size: 35px;
}
.btn-primary:hover, .btn-primary:focus {
    background: #333;
    opacity: 0.9;
}
.close:hover, .close:focus {

    opacity:0.6;
}
span.tnl-image-flex img {
    margin-right: 6px;
}
.tnl-image-flex {
    margin-right: 5px;
}
body.base-page-body {
    overflow:visible !important;
}
@media only screen and (max-width:1040px) and (min-width:1016px) {
.close {
    margin-top: -22px;
}

}
@media only screen and (min-width:800px) and (max-width:1050px){
.modal-body {
    padding-left: 10px;
}

.btn-primary {
    margin-left: 10px;
}


}
@media only screen and (min-width:800px) and (max-width:820px){

.tnl-parent-flex {justify-content: start;}

    }
@media only screen and (max-width:1015px) and (min-width:759px) {

.close {
    margin-top: -36px;
    right: 11px;
}
.modal-body {
   padding-right: 0;
    padding-left: 5px;
    padding-top: 35px;
}
.modal {
    top: calc(100% - 110px) !important;
}
.tnl-parent-flex p {
    font-size: 16px;
}
.btn-primary {
    width: 90px;
    height: 35px;
    margin-left: 13px;
    font-size: 13px;
}

span.tnl-image-flex img {
    margin-right: 0;
}
}

@media only screen and (max-width:758px) {

 .close {
    right:0;
 }
.modal-body {
    padding: 25px;
    padding-top: 20px;
    padding-bottom: 16px;
}

span.tnl-image-flex img {
    height: 38px;
}

.tnl-parent-flex > p {
    margin-top: 6px;
    margin-bottom: 6px;
}
.modal {
    top: calc(100% - 250px) !important;
}


.tnl-parent-flex {
    flex-direction: column;
    align-items: self-start;
}

.tnl-parent-flex > p {
    font-size: 16px;
    margin-left: 6px;
}

.btn-primary {
    margin-left: 6px;
    width: 100%;
    margin-top: 10px;
}
}
</style>