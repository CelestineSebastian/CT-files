<script>

    function allEvents(){

        $(document).on("click","a#Check-Other-Stores",function(){
        $(".section-header-container.collapse-product-availability").click();
        });

        $(document).on("click",".section-header-container.collapse-videos,.collapse-videos",function(){
        var selector = $("div#pdp-video-selector");
        var _this = $(this);
        callBack(selector,_this);
        });

        $(document).on("click",".section-header-container.collapse-product-availability,.collapse-product-availability",function(){
        var selector = $(".parbase.store-availability.section");
        var _this = $(this);
        callBack(selector,_this);
        });

        $(document).on("click",".section-header-container.collapse-reviews,.collapse-reviews",function(){
        var selector = $(".base-tabs.product-reputation-tab.parbase.section");
        var _this = $(this);
        callBack(selector,_this);
        });

        /* Header rating click */

        $(document).on("click",".pdp-header__reviews",function(){
        var selector = $(".base-tabs.product-reputation-tab.parbase.section");
        var _this = $(".collapse-reviews");
        callBackNew(selector,_this);
         $('html,body').animate({scrollTop: $("#collapse-reviews").offset().top},'slow');
       
        });

        /* End of Header rating Click */
        $(".section-header-container.collapse-reviews").attr("id","collapse-reviews");

        $("div#pdp-video-selector,.parbase.store-availability.section,.base-tabs.product-reputation-tab.parbase.section").addClass("displayNone");



        if ( $(".rotate.collapse-videos").length < 1 ){
        var $collapseVideos = $('<div class="rotate collapse-videos">+</div>');

            $collapseVideos.insertAfter(".section-header-container.collapse-videos");
    	}

    	if ( $(".rotate.collapse-product-availability").length < 1 ){

        var $collapseProduct = $('<div class="rotate collapse-product-availability">+</div>');

            $collapseProduct.insertAfter(".section-header-container.collapse-product-availability");
    	}

    	if ( $(".rotate.collapse-reviews").length < 1 ){
      
            var $collapseReviews = $('<div class="rotate collapse-reviews">+</div>');

             $collapseReviews.insertAfter(".section-header-container.collapse-reviews");
    	}


        function callBackNew(selector,_this){
        //console.log(_this);
                   if ( $(_this).find("rotateClass").length < 1) {
                    selector.removeClass("displayNone");
                    _this.addClass("rotateClass");
                    _this.siblings().addClass("rotateClass");
                }

        }


        function callBack(selector,_this){
        //console.log(_this);
        		if ( selector.hasClass("displayNone") == false ) {
        			selector.addClass("displayNone");
                    _this.removeClass("rotateClass");
                    _this.siblings().removeClass("rotateClass");
                 }
        		else {
        			selector.removeClass("displayNone");
                    _this.addClass("rotateClass");
                    _this.siblings().addClass("rotateClass");
        			}
        }


    }


    function timerFunction(){
    var timesRun = 0;
    var stopTimer = setInterval(function(){
    timesRun += 1;
    if(timesRun < 60){
        allEvents();
        clearInterval(stopTimer);
        } 
    }, 1000); 
    }

    timerFunction();

</script>



<style>


.pdp-details-features__items ul li:before, .pdp-long-description__items ul li:before {
    color: #333;
}

.collapse-details:before,
.collapse-details:after,
.collapse-videos .section-header-lines-about:before,
.collapse-videos .section-header-lines-about:after,
.collapse-product-availability .section-header-lines-about:before,
.collapse-product-availability .section-header-lines-about:after,
.collapse-reviews .section-header-lines-about:before,
.collapse-reviews .section-header-lines-about:after
{ display:none }







.collapse-details,.collapse-reviews,.collapse-videos,.collapse-product-availability{border-top: 1px solid #ccc;line-height: 0 !important;padding: 8px 0;width: 95%;margin: 0 auto;display: flex;align-items: center;justify-content: space-between;


 -webkit-transition: -webkit-transform 0.3s ease-out;
    -ms-transition: -ms-transform 0.3s ease-out;
    transition: transform 0.3s ease-out;

    }
.displayNone {
    display: none !important;
}

.section-header-container {
    padding-left: 0;
    padding-right: 0;
    display: flex;
    align-items: center;
    justify-content: space-between;
}


.section-header-lines-about.collapse-details > div:after, .collapse-videos:after, .collapse-product-availability:after, .collapse-reviews:after {/* content: "+"; *//* display: block; *//* border: 0; *//* background: none; *//* margin: 0; *//* width: 20%; *//* font-size: 24px; *//* position: absolute; *//* right: -50px; */}

.section-header-lines-about {
    text-align: left;
}

.section-header-line {
    padding-top: 0 !important;
}

.collapse-reviews {
    border-bottom: 1px solid #ccc;
    padding-bottom: 12px;
}



.section-header-container.collapse-videos {
    -webkit-transition: -webkit-transform .3s ease-in-out;
    -ms-transition: -ms-transform .3s ease-in-out;
    transition: transform .3s ease-in-out;
}



.rotate {
    border: 0;
    width: auto;
    font-size: 24px;
    position: absolute;
    right: 24px;
    padding: 12px 5px;
    border-radius: 50%;
    top: 22px;
    font-weight:bold;
}

.rotate.rotateClass {
    transform: rotate(45deg);
    
}




.rotate.collapse-product-availability, .rotate.collapse-videos,.rotate.collapse-reviews {
    top: 7px;
    right: 30px;
}

.pdp-details__inner,.pdp-info-component__col,.pdp-video-selector__video-list__ctas,.pdp-video-selector__video-list__ctas__button__previous,.pdp-video-selector__video-aside    {
    border: 0;
}

.product-reputation .section-header-paddings {
    padding: 16px 7px;
}

.pdp-details {
    padding-bottom: 0px;
}

.pdp-details-features__heading {
    margin-top: 16px;
}

.pdp-store-availability {
    padding-top: 16px;
}

.store-list__tab__content__map__accordion__panel-content .store-list__tab__content__list-item__accordion__store-pin {
    margin: 0 !important;
}

.need_2_order_more__tooltip_link i::after {
    position: relative;
    right: 0;
}

.need_2_order_more__tooltip_link {
    font-weight: 700;
}

		</style>